import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './index.css'
import withAuth from './hoc/withAuth'
import AdminLayout from './pages/AdminLayout'

function App() {
  const Main = withAuth(AdminLayout)
  return (<Main/>)            
 }

export default App
