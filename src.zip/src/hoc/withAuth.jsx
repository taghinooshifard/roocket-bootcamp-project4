import Login from '../pages/Login'

function withAuth(MyPage) {
  return function Authenticate(props){
    let allow = false
    if(allow)
        return <MyPage {...props}/>
    else
      return  <Login/>
  }
}

export default withAuth